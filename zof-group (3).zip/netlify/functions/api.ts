import express from "express";
import serverless from "serverless-http";
import apiRouter from "../../src/apiRouter.js";

const app = express();
app.use(express.json());

// Support the API router mounted at standard, function-prefixed, and stripped proxy paths
app.use("/api", apiRouter);
app.use("/.netlify/functions/api", apiRouter);
app.use("/", apiRouter);

export const handler = serverless(app);
